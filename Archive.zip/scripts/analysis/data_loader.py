"""
Load the simulation data

for further quantitative analysis

NOT SURE: whether to add the part that checks if the metadata are the same when reading a group of data

"""
import numpy as np
import glob
import os

from pathlib import Path

def get_data_dir(file_str: str) -> Path:
    """
    Safely resolves the data directory whether run from a terminal script
    or imported inside a Jupyter Notebook.
    """
    try:
        # 1. SCENARIO: Running as a standard Python script (.py)
        # Assuming script is in project_root_folder/scripts/analysis/
        project_root = Path(__file__).resolve().parent.parent.parent # analysis > scripts > root folder
        
    except NameError:
        # 2. SCENARIO: Running interactively in a Jupyter Notebook!
        # Notebooks don't have __file__. We use the Current Working Directory.
        current_dir = Path(os.getcwd()).resolve()
        
        project_root = current_dir.parent # notebooks are inside a 'notebooks' folder, go up one level
        

    # 3. Build the exact requested path to save simulated data
    data_dir = project_root /"simulation_data"/file_str
    
    # 4. Create the folders automatically if they don't exist yet!
    data_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"Data directory set to: {data_dir}")

    return data_dir


def load_well_mixed_data(file_str):
    """
    Universal loader for any well-mixed model (Schlögl or Full).
    Returns a dictionary of combined arrays and a list of individual trajectories.
    """
    DATA_DIR = get_data_dir(file_str)
    file_pattern = os.path.join(DATA_DIR, "run_data_*.npz")
    data_files = glob.glob(file_pattern)

    if not data_files:
        print(f" Error: No files found in {DATA_DIR}")
        return None, None, None

    # This dictionary will store lists of arrays for every key found in the files
    # e.g., storage['X'] = [array_run1, array_run2...]
    storage = {} # store the concatenated data of all trajectories for one species, separate by species name
    trajectories = [] # store (time, species_dict) for plotting lines
    metadata = {} # information about parameter setting

    for f in data_files:
        try:
            with np.load(f) as data: # equals to: data = np.load(f)
                # 1. Automatically detect what species are in this file
                # species_keys = 'X' for Schloegl; 'X', 'X2' for Full model
                species_keys = [i for i in data.files if i not in ['Time', 'l', 'k', 'tau', 'vol',
                                                                   't_f', 'a', 'b']]
                                
                # 2. Extract Species Data
                run_species_log = {}
                for s in species_keys:
                    
                    # Initialize storage list if it's the first time we see this species
                    if s not in storage: storage[s] = []    
                    species_data = data[s]
                    # print(species_data)
                    storage[s].append(species_data)
                    run_species_log[s] = species_data

                # 3. Extract Time (used for trajectory plots)
                t_data = data['Time']

                # 4. Save individual trajectory
                trajectories.append({'timescale': t_data, 'species_log': run_species_log})
                
                # 5. Capture Metadata (ls or k) - only need to do this once
                if not metadata:
                    metadata['macrorates'] = data['l'] if 'l' in data.files else data['k']
                    metadata['timestep'] = data['tau']
                    metadata['timespan'] = data['t_f']
                    metadata['a'] = data['a']
                    metadata['b'] = data['b']
                    metadata['vol'] = data['vol']

        except Exception as e:
            print(f" Error loading {os.path.basename(f)}: {e}") # return the file name only, rather than the full path 

    # Combine all data points for the Histogram/KDE
    combined_data = {s: np.concatenate(storage[s]) for s in storage}

    print(f" Loaded {len(data_files)} runs. Combined {len(combined_data['X'])} points.")
    return trajectories, combined_data, metadata



def load_spatial_full_data(file_str, slice_val=10000):
    """
    data loader for the spatial simulation data
    """

    DATA_DIR = get_data_dir(file_str)
    file_pattern = os.path.join(DATA_DIR, "run_data_spatial_*.npz")
    data_files = glob.glob(file_pattern)

    if not data_files:
        print(f" Error: No files found in {DATA_DIR}")
        return None, None, None, None, None
    
    # all_data_X, all_data_X2, trajectories = [], [], []
    all_data_X = []
    all_data_X2 = []
    trajectories = []
    metadata = {}
    collective_pos_X = []
    collective_pos_X2 = []
    pos_Time = []

    for f in data_files:
        try:
            with np.load(f, allow_pickle=True) as data:
                
                t_data = data['Time'][::slice_val].copy()

                run_species_log = {}

                sliced_X = data['X'][::slice_val].copy()
                sliced_X2 = data['X2'][::slice_val].copy()

                all_data_X.append(sliced_X) # data['X']
                all_data_X2.append(sliced_X2) # data['X2']
                run_species_log['X'] = sliced_X # data['X']
                run_species_log['X2'] = sliced_X2 # data['X2']
                trajectories.append({'timescale': t_data, 'species_log': run_species_log})

                collective_pos_X.append(data['pos_X']) 
                if 'pos_X2' in data.files:
                    collective_pos_X2.append(data['pos_X2'])

                if len(pos_Time)==0:
                    pos_Time = data['pos_Time']

                if not metadata:
                    metadata['macrorates'] = data['l'] # idk why writting them in the same line with a comma dont work
                    metadata['microrates'] = data['kappa']
                    metadata['timestep'] = data['tau']
                    metadata['timespan'] = data['t_f']
                    metadata['a'] = data['a']
                    metadata['b'] = data['b']
                    metadata['box_shape'] = data['box_shape']
                    metadata['sigma'] = data['sigma']
                    metadata['D'] = data['D']
                    metadata['p'] = data['p']
                    metadata['q'] = data['q']

        except Exception as e:
            print(f" Error loading {os.path.basename(f)}: {e}") # return the file name only, rather than the full path 

    # Combine all data points for the Histogram/KDE
    combined_data = {}
    combined_data['X'] = np.concatenate(all_data_X)
    combined_data['X2'] = np.concatenate(all_data_X2)
    collective_pos = []
    collective_pos.append(collective_pos_X)
    if len(collective_pos_X2):
        collective_pos.append(collective_pos_X2)
    print(f" Loaded {len(data_files)} runs. Combined {len(combined_data['X'])} points.")
    return trajectories, combined_data, collective_pos, pos_Time, metadata


